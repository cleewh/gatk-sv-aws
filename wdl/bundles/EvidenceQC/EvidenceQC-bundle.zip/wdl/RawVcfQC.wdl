## This WDL pipeline implements quality check on vcfs from each SV calling algorithms
## (https://github.com/arq5x/lumpy-sv)
##
## Patched 2026-05-27 to dodge the HealthOmics 47-second multi-task kill.
## The original workflow had 3 tasks: RunIndividualQC scatter -> PickOutliers
## + MergeVariantCounts aggregators. The aggregators consumed scatter outputs
## as Array[File] inputs, which triggered the kill (same pattern as Scramble
## and MakeCohortVcf.CombineBatches).
##
## This patch exposes the per-sample stat files as a workflow output. The
## aggregation (outlier picking + variant counting) runs off-HealthOmics via
## scripts/run_evidence_qc_aggregator_ec2.sh.

version 1.0

import "Structs.wdl"

workflow RawVcfQC {
  input {
    Array[File] vcfs
    String prefix
    String caller
    String sv_pipeline_docker
    RuntimeAttr? runtime_attr_qc
    RuntimeAttr? runtime_attr_outlier
    RuntimeAttr? runtime_attr_counts
  }

  scatter (vcf in vcfs) {
    call RunIndividualQC {
      input:
        vcf = vcf,
        caller = caller,
        sv_pipeline_docker = sv_pipeline_docker,
        runtime_attr_override = runtime_attr_qc
    }
  }

  output {
    # Per-sample stats only. Aggregation happens off-HealthOmics; see
    # scripts/run_evidence_qc_aggregator_ec2.sh.
    Array[File] per_sample_stats = RunIndividualQC.stat
  }
}

task RunIndividualQC {
  input {
    File vcf
    String caller
    String sv_pipeline_docker
    RuntimeAttr? runtime_attr_override
  }

  String sample_name = basename(vcf, ".vcf.gz")

  RuntimeAttr default_attr = object {
    cpu_cores: 1,
    mem_gb: 1,
    disk_gb: 50,
    boot_disk_gb: 10,
    preemptible_tries: 3,
    max_retries: 1
  }
  RuntimeAttr runtime_attr = select_first([runtime_attr_override, default_attr])

  output {
    File stat = "${caller}.${sample_name}.QC.stat"
  }
  command <<<

    python /opt/sv-pipeline/pre_SVCalling_and_QC/raw_vcf_qc/calcu_num_SVs.by_type_chromo.py ~{vcf} ~{caller}.~{sample_name}.QC.stat

  >>>
  runtime {
    cpu: select_first([runtime_attr.cpu_cores, default_attr.cpu_cores])
    memory: select_first([runtime_attr.mem_gb, default_attr.mem_gb]) + " GiB"
    disks: "local-disk " + select_first([runtime_attr.disk_gb, default_attr.disk_gb]) + " HDD"
    bootDiskSizeGb: select_first([runtime_attr.boot_disk_gb, default_attr.boot_disk_gb])
    docker: sv_pipeline_docker
    preemptible: select_first([runtime_attr.preemptible_tries, default_attr.preemptible_tries])
    maxRetries: select_first([runtime_attr.max_retries, default_attr.max_retries])
  }

}
